# MN Cut v30

MN Cut is a WebView-based Android video editor prototype with a multi-clip timeline, trimming, split/duplicate, transitions, text overlays, filters, SRT subtitles, audio tracks, project save/load, automatic draft recovery, and combined timeline export.

## Build APK with GitHub Actions

1. Extract this ZIP so `settings.gradle`, `build.gradle`, and `app/` are directly in the repository root.
2. Push the files to GitHub (main or master), or run the **Build MN Cut APK** workflow manually.
3. Download the `MN-Cut-debug-apk` artifact from the completed workflow.

## Export notes

- Combined timeline rendering is performed in the WebView and produces a WebM intermediate.
- In the Android app, Media3 Transformer attempts to convert that intermediate to H.264/AAC MP4 and saves it to Downloads. Browser-only export remains WebM.
- Android MP4 conversion can be cancelled while Media3 is running. Duplicate conversion starts are blocked, cancellation is checked again before publishing, and empty output files are rejected. Temporary input/output files are cleaned up on completion or failure; each export receives a unique filename. Actual codec/device compatibility must be tested on a physical Android device.
- This project has not been built or device-tested in this environment. GitHub Actions is configured to build a debug APK; the workflow result is the required compilation check.
